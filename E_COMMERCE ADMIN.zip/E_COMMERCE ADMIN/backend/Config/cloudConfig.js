import cloudinary from 'cloudinary'

const uploader = cloudinary.v2
uploader.config({
    cloud_name: process.env.CLOUD_NAME,
    api_key: process.env.CLOUD_API_KEY,
    api_secret: process.env.CLOUD_API_SECRET
})
export default uploader;