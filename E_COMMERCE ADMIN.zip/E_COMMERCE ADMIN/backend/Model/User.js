import mongoose from "mongoose";

const Address = new mongoose.Schema({
    country: { type: String, require: true },
    state: { type: String, require: true },
    distt: { type: String, require: true },
    village: { type: String, require: true },
    pincode: { type: Number, min: 6, max: 6, require: true },
    landmark: { type: String, require: true }
})

const User = new mongoose.Schema({
    name: { type: String, require: true },
    gender: { type: String, require: true },
    mobile: { type: Number, require: true },
    altMobile: { type: Number, require: true },
    email: { type: String, require: true },
    image: { type: String, require: true },
    address: [Address],
})

export default User;